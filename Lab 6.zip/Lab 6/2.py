import numpy as np
from sklearn.datasets import load_iris
from sklearn.decomposition import PCA
import matplotlib.pyplot as plt

iris = load_iris()
X = iris.data  
y = iris.target  

pca = PCA(n_components=2)
X_reduced = pca.fit_transform(X)

pc1 = X_reduced[:, 0]
pc2 = X_reduced[:, 1]

plt.figure(figsize=(8, 6))  
plt.scatter(pc1, pc2, c=y, cmap="plasma", edgecolors='k')

plt.xlabel("Principal Component 1", fontsize=12)
plt.ylabel("Principal Component 2", fontsize=12)

plt.legend(iris.target_names, title="Iris Species", loc='upper right', fontsize=12)

plt.title("Iris dataset in 2D using PCA", fontsize=14)
plt.grid(True)  
plt.tight_layout()  
plt.show()
