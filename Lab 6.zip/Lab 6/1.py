import numpy as np
import matplotlib.pyplot as plt

data = np.array([(2, 1), (3, 4), (5, 0), (7, 6), (9, 2)])


mean = data.mean(axis=0)
centered_data = data - mean

covariance = np.cov(centered_data.T)

eigenvalues, eigenvectors = np.linalg.eig(covariance)

sorted_index = np.argsort(eigenvalues)[::-1]
eigenvalues = eigenvalues[sorted_index]
eigenvectors = eigenvectors[:, sorted_index]

principal_component = eigenvectors[:, 0]

transformed_data = centered_data.dot(principal_component.reshape(-1, 1))

plt.figure(figsize=(10, 6))

# Original space
plt.subplot(121)
plt.scatter(data[:, 0], data[:, 1], label='Original data')
plt.xlabel('Feature 1')
plt.ylabel('Feature 2')
plt.title('Original Data')
plt.legend()

# Transformed space
plt.subplot(122)
plt.scatter(transformed_data, np.zeros_like(transformed_data), label='Transformed data')
plt.xlabel('Principal Component')
plt.ylabel('Feature 2 (projected)')  
plt.title('Transformed Data')
plt.legend()

plt.tight_layout()
plt.show()
